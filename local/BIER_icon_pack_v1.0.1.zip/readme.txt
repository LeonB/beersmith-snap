﻿╔═══════════════════════════════════╗
║   The BeerSmith Icon Enhancement  ║            .o.o.oo..
║          & Revision Add-On        ║          .OoOoOoOoOo.
╚═══════════════════════════════════╝           oOoO .   ||____
                                                ||oo     ||___ \ 
   by Zemba Craftworks                          ||o   .  ||  | |
        zembacraftworks.com                     ||  .    ||  | |
        youtube.com/zembacraftworks             ||     | ||  | |
                                                || | . | ||__| |
   Current Release:   1.0.1 (2019-06-20)        ||_|___|_||____/
                                                |_________|

   The BeerSmith Icon Enhancement & Revision (BIER) Add-On is a complete set
   of 140+ new, completely unofficial icons for BeerSmith homebrewing software.
   The BIER icon set has a simple, flat, material design theme that is intended
   to enhance the overall experience of using BeerSmith.

╔═══════════════════════════════════╗
║           Installation            ║
╚═══════════════════════════════════╝

   Installing BIER will replace BeerSmith's existing icons, so you may wish to
   back them up first to give you the option of easily returning to the stock
   UI. You can do so by locating the "icons" directory in your BeerSmith folder
   and renaming it "icons_backup".

   The BeerSmith directory for Windows can usually be found at:

      "C:\Program Files (x86)\BeerSmith3\"

   To add the BIER icon pack to your copy of BeerSmith, simply extract the
   "icons" folder from this zip file to your BeerSmith directory, replacing
   the existing "icons" folder and the images it contains. 

╔═══════════════════════════════════╗
║           Compatibility           ║
╚═══════════════════════════════════╝

   BIER was designed for the Windows version of BeerSmith 3 and has been tested
   on Windows 7 and Windows 10. Please let me know if you try it out on
   additional platforms with success or failure!

╔═══════════════════════════════════╗
║          The Noun Project         ║
╚═══════════════════════════════════╝

   Many of the icons in the BIER Add-On are either from or inspired by
   The Noun Project, a creative commons resource for royalty free icons.

   Below is a list of artists who helped make BIER possible through their
   contributions to The Noun Project:

      Appearance by Ayub Irawan     Heart by Ben Iconator             Puzzle by Bluetip Design
      Apple by Lyhn                 Home by Frey Wazza                Scissors by Icon Lauk
      Arrow Left by Mike Rowe       Honey by Styleku                  Shopping Cart by Adrien Coquet
      Binoculars by Kiran           Hops by David Lamm                Thermometer by Guillem Sevilla
      Bubbles by Rudez Studio       Key by Kyle Dodson                Tools by HrBonPro  
      Calendar by Adrien Coquet     Magnif. Glass by Vectors Market   Undo by Farrel Putra
      Carboy by Mark Caron          Measuring Cup by Jake Park        Vial by Arafat Uddin
      Check by Focus                Monitor by TS Graphics            Vials by Yo! Baba
      Clock by Yo! Baba             Note by Benny Forsberg            Warning by Gregor Cresnar
      Cloud by Humantech            Options by Marie Van den Broeck   Water by Bluetip Design
      Copy by Mochammad Kafi        Package by Kokota                 Weight by Styleku
      Dollar by Musmellow           Paper Bag by Arthur Shlain        Wheat by Alice Design
      Flag by Vectors Point         Paperclip by Zulfahmi Al Ridhawi  Window by Icon 54
      Floppy by Markus              Paste by Omar Safaa               Wizard by Ralf Schmitzer
      Folder by Saifurrijal         Pint Glass by Mark Caron          X by Fardan 
      Gauge by Alexander Skowalsky  Plus/Minus by Muneer A Safiah
      Gear by Humantech             Print by Georgiana Ionescu
      Globe by Piotrek Chuchla      Profile by ghufronagustian

╔═══════════════════════════════════╗
║          Version History          ║
╚═══════════════════════════════════╝
┌───┬────────────┬──────────┬───────────────────────────────────────────┐
│   │ Date       │ Version  │  Details                                  │
└───┴────────────┴──────────┴───────────────────────────────────────────┘

  •   2019-06-20   v1.0.0      Initial Release
                                 - Icon Count: 200 icons replaced

  •   2019-06-20   v1.0.1      Updated some icons missing their latest
                               revisions in 1.0.0:
                                 - LME (all sizes, color adjustment)
				 - Decoction16.png (AA fix)
				 - WeightToVolume16.png (AA fix)